package dongguk.yamyam.helper;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import dongguk.yamyam.fragment.DetailFragment;
import dongguk.yamyam.fragment.DetailGpsFragment;
import dongguk.yamyam.fragment.SearchFragment;

public class DetailTabAdapter extends FragmentStatePagerAdapter {

    // Count number of tabs
    private int tabCount;

    public DetailTabAdapter(FragmentManager fm, int tabCount) {
        super(fm);
        this.tabCount = tabCount;
    }

    @Override
    public Fragment getItem(int position) {

        // Returning the current tabs
        switch (position) {
            case 0:
                DetailFragment tabFragment1 = new DetailFragment();
                return tabFragment1;
            case 1:
                SearchFragment tabFragment2 = new SearchFragment();
                return tabFragment2;
            case 2:
                DetailGpsFragment tabFragment3 = new DetailGpsFragment();
                return tabFragment3;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return tabCount;
    }

    @Override
    public int getItemPosition(Object object) {
        // POSITION_NONE makes it possible to reload the PagerAdapter
        return POSITION_NONE;
    }
}