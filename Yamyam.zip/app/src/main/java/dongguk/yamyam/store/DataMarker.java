package dongguk.yamyam.store;

/**
 * Created by SJ on 2016-11-25.
 */
public class DataMarker {
    public double lon;
    public double lat;

    public DataMarker(double lon, double lat){
        this.lon = lon;
        this.lat = lat;
    }
}
