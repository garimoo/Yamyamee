package dongguk.yamyam.store;

/**
 * Created by SJ on 2016-11-23.
 */
public class DataNotice {
    public String noticeId;
    public String noticeName;
    public String noticeDate;
}
