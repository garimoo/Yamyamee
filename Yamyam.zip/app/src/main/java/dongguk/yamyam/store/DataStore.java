package dongguk.yamyam.store;

/**
 * Created by SJ on 2016-11-07.
 */
public class DataStore {
    public String storeKey;
    public String storeName;
    public String storeAddress;
    public String storeSubject;
    public String storePhone;
    public String storeLatX;
    public String storeLongY;
    public float storeDistance;
    public float storeScore;
}