package dongguk.yamyam.store;

/**
 * Created by SJ on 2016-11-14.
 */
public class DataReview {
    public String reviewId;
    public String reviewDate;
    public String reviewContent;
}
