package dongguk.yamyam.activity;

/**
 * Created by SJ on 2016-11-25.
 */

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import dongguk.yamyam.R;

public class IntroActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);
    }

}
